export class JobSeeker{
    id:number;
    username:string;
    name:string;
    phone:number;
    email:string;
    password:number;

    constructor(){
        this.id=0;
        this.username="";
        this.name="";
        this.phone=0;
        this.email="";
        this.password=0;
    }
}