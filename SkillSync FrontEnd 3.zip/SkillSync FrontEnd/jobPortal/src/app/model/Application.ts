export class Application{
    applicationid:number;
    name:string;
    address:string;
    educational_details:string;
    experience:number;

    constructor(){
        this.applicationid=0;
        this.name="";
        this.address="";
        this.educational_details="";
        this.experience=0;
    }
}